package com.splitwise.models;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class SplitRequest {
	private User spender;
	private List<SplitTypeUser> owers;
	private SplitType type;
	private BigDecimal amount;
}
