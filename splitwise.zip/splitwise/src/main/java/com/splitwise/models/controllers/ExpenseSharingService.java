package com.splitwise.models.controllers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.splitwise.models.ExpenseDetails;
import com.splitwise.models.SplitRequest;
import com.splitwise.models.SplitType;
import com.splitwise.models.SplitTypeUser;
import com.splitwise.models.User;

@Component
public class ExpenseSharingService {

	private List<User> users = new ArrayList<>();
	private Map<Integer, User> usersData = new HashMap<>();
	private List<ExpenseDetails> expenseDetails = new ArrayList<>();
	private Map<Long, Map<Long, BigDecimal>> balances = new HashMap<>();

	public ExpenseSharingService() {
		createUserData();
	}

	void createUserData() {
		User user;
		int i = 1;
		while (i <= 4) {
			user = new User(i, "U" + i, "number");
			users.add(new User(i, "U" + i, "number"));
			usersData.put(i, user);
			i++;
		}

	}

	void logExpense(SplitRequest ex) {
		if (ex.getType().equals(SplitType.EQUAL)) {
			equalSplitting(ex);
		} else if (ex.getType().equals(SplitType.EXACT)) {
			exactSplitting(ex);
		} else if (ex.getType().equals(SplitType.PERCENT)) {
			percentgeSplitting(ex);
		}
	}

	void equalSplitting(SplitRequest ex) {
		User spender = ex.getSpender();
		List<SplitTypeUser> owers = ex.getOwers();
		int len = ex.getOwers().size();
		BigDecimal amount = ex.getAmount().divide(new BigDecimal(len + 1));
		for (SplitTypeUser ower : owers) {
			ExpenseDetails expenseDetail = new ExpenseDetails(spender, ower.getUser(), amount);
			expenseDetails.add(expenseDetail);
		}
	}

	void exactSplitting(SplitRequest ex) {
		User spender = ex.getSpender();
		List<SplitTypeUser> owers = ex.getOwers();
		for (SplitTypeUser ower : owers) {
			ExpenseDetails expenseDetail = new ExpenseDetails(spender, ower.getUser(), new BigDecimal(ower.getRatio()));
			expenseDetails.add(expenseDetail);
		}
	}

	void percentgeSplitting(SplitRequest ex) {
		User spender = ex.getSpender();
		List<SplitTypeUser> owers = ex.getOwers();
		for (SplitTypeUser ower : owers) {
			int ratio = ower.getRatio();
			BigDecimal amount = ex.getAmount().multiply(new BigDecimal(ratio)).divide(new BigDecimal(100));
			ExpenseDetails expenseDetail = new ExpenseDetails(spender, ower.getUser(), amount);
			expenseDetails.add(expenseDetail);
		}
	}

	public void addToBalance(ExpenseDetails exp) {
		User lender = exp.getLender();
		Map<Long, BigDecimal> lenderMap = balances.getOrDefault(lender.getId(), new HashMap<Long, BigDecimal>());
		BigDecimal borrowers = lenderMap.getOrDefault(exp.getBorrower().getId(), new BigDecimal(0));
		borrowers = borrowers.add(exp.getAmount());
		lenderMap.put(lender.getId(), borrowers);
		balances.put(lender.getId(), lenderMap);
	}

	List<String> getBalances() {
		List<String> res = new ArrayList<>();
		Set<Long> keySet = balances.keySet();
		for (Long userId : keySet) {
			Map<Long, BigDecimal> lenderMap = balances.get(userId);
			Set<Long> borrowers = balances.get(userId).keySet();
			for (Long borrowerId : borrowers) {
				res.add("U" + borrowerId + " owes " + "U" + userId + " : " + lenderMap.get(borrowerId));
			}
		}

		return res;
	}

}
