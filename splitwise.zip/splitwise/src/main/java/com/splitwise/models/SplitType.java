package com.splitwise.models;

public enum SplitType {
	EQUAL, EXACT, PERCENT

}
