package com.splitwise.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splitwise.models.SplitRequest;

@RestController
public class ExpenseSharingController {

	@Autowired
	private ExpenseSharingService expenseSharingService;

	@PostMapping("/logExpense")
	public ResponseEntity<String> logExpense(SplitRequest ex) {
		expenseSharingService.logExpense(ex);
		return new ResponseEntity<String>("Success", HttpStatusCode.valueOf(200));
	}

	@PostMapping("/showBalances")
	public ResponseEntity<List<String>> showBalances() {
		return new ResponseEntity<List<String>>(expenseSharingService.getBalances(), HttpStatusCode.valueOf(200));
	}

}
