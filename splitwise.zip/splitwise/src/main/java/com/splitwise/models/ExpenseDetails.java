package com.splitwise.models;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ExpenseDetails {
	private User lender;
	private User borrower;
	private BigDecimal amount;
}
